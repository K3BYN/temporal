const meses = ['Enero', 'Febrero'];
const meses2 = ['Marzo', 'Abril'];
const meses3 = ['Mayo', 'Junio'];

const myArray = meses.concat(meses2, meses3);
console.log(myArray);


const resultado = [...meses, ...meses2, ...meses3];
console.log(resultado);