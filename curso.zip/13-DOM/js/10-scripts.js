// const enlace = document.createElement('A');

// //Agregando el texto
// enlace.textContent = 'Nuevo Enlace';

// //Añadiendo href
// enlace.href = '#';

// console.log(enlace);

// enlace.target = '_blank';

// enlace.setAttribute('data-enlace', 'nuevo-enlace');
// enlace.classList.add('alguna-clase');
// enlace.onclick = miFuncion;

// //Seleccionar la navegación
// const navegacion = document.querySelector('.navegacion');
// navegacion.insertBefore(enlace, navegacion.children[1]);

// function miFuncion() {
//     alert('Diste click');
// }


//Creando CARD
const parrafo1 = document.createElement('P');
parrafo1.textContent = "Concierto";
parrafo1.classList.add('categoria', 'concierto');

const parrafo2 = document.createElement('P');
parrafo2.textContent = 'Música de Rammstein';
parrafo2.classList.add('titulo');

const parrafo3 = document.createElement('P');
parrafo3.textContent = '$2,200 por persona';
parrafo3.classList.add('precio');

//Creando div
const div = document.createElement('div');
div.classList.add('info');

//metiendo el card dentro del div
div.appendChild(parrafo1);
div.appendChild(parrafo2);
div.appendChild(parrafo3);

//imagen del card
img = document.createElement('img');
img.src = "img/hacer3.jpg";

//creando div padre
const div2 = document.createElement('div');
div2.classList.add('card');

//metiendo todo al div padre
div2.appendChild(img);
div2.appendChild(div);

//posicionando nuestro card
const card2 = document.querySelector('.contenedor-cards');
card2.insertBefore(div2, card2.children[1]);
