const card = document.querySelectorAll('.card');
console.log(card);

const formulario = document.querySelectorAll('#formulario');
console.log(formulario);

const no_existe = document.querySelectorAll('no-existe');
console.log(no_existe);