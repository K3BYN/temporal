const encabezado = document.querySelector('h1');
encabezado.style.backgroundColor = 'red';
encabezado.style.fontFamily = 'Arial';
encabezado.style.textTransform = 'uppercase';

const card = document.querySelector('.card');
card.classList.add('nueva-clase', 'segunda-nueva-clase');
card.classList.remove('segunda-nueva-clase');
console.log(card.classList);