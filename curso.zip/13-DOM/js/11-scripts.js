const btnflotante = document.querySelector('.btn-flotante');
const footer = document.querySelector('.footer');

btnflotante.addEventListener('click', mostrarOcultarFooter);

function mostrarOcultarFooter() {
    footer.classList.contains("activo")
        ? (btnflotante.classList.remove("activo"), footer.classList.remove("activo"),
            btnflotante.textContent = 'Idioma y Moneda'
        )
        : (btnflotante.classList.add("activo"), footer.classList.add("activo"),
            btnflotante.textContent = 'X Cerrar'
      );
}
