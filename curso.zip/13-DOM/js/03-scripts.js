const formulario = document.getElementById('formulario');
console.log(formulario);