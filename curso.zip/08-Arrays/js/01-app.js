const numeros = [1, 2, 3, 4, 5, 6];
const meses = new Array('enero', 'febrero', 'marzo');

console.log(numeros);
console.log(meses);

const deTodo = [1, 'hola', true, null, { nombre: 'kevin' }, [1, 2, 3]];
console.log(deTodo);