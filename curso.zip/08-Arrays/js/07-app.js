const carrito = [];

const producto = {
  nombre: "tablet",
  precio: 14000,
};

const producto2 = {
  nombre: "celular",
  precio: 9000,
};

const producto3 = {
    nombre: "monitor",
    precio: 8000,
};

const producto4 = {
  nombre: "pantalla",
  precio: 8000,
};

const producto5 = {
  nombre: "laptop",
  precio: 8000,
};
carrito.push(producto);
carrito.push(producto2);
carrito.push(producto3);
carrito.push(producto4);
carrito.push(producto5);

console.table(carrito);

carrito.pop();
console.table(carrito);

carrito.shift();
console.table(carrito);

carrito.splice(1, 1);
console.table(carrito);