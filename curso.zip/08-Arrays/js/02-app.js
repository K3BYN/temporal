const numeros = [1, 2, 3, [4, 5, 6]];

console.table(numeros);
console.log(numeros[3][2]);