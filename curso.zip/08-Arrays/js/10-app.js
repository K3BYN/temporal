const carrito = [
  { nombre: "celular", precio: 7800 },
  { nombre: "tablet", precio: 14000 },
  { nombre: "televisión", precio: 12000 },
  { nombre: "colchón", precio: 8000 },
  { nombre: "teclado", precio: 1000 },
  { nombre: "audífonos", precio: 1200 },
];

const nuevoArreglo = carrito.map(function (producto) {
    return(`${producto.nombre} - Precio: ${producto.precio}`);
});


carrito.forEach(function (producto) {
  console.log(`${producto.nombre} - Precio: ${producto.precio}`);
});


console.log(nuevoArreglo);

/**La diferencia entre forEach y map es que map puede crear una nueva variable donde guardar el arreglo y se puede
 * utilizar por ejemplo para guardar los precios de más de $700
 */