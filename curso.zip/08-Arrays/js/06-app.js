const carrito = [];

const producto = {
  nombre: "tablet",
  precio: 14000,
};

const producto2 = {
  nombre: "celular",
  precio: 9000,
};

const producto3 = {
  nombre: "monitor",
  precio: 8000,
};

let newCarrito;

newCarrito = [...carrito, producto];
newCarrito = [...newCarrito, producto2];
newCarrito = [producto3, ...newCarrito];

console.table(newCarrito);
