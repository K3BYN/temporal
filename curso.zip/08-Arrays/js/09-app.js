const carrito = [
    { nombre: "celular", precio: 7800 },
    { nombre: "tablet", precio: 14000 },
    { nombre: "televisión", precio: 12000 },
    { nombre: "colchón", precio: 8000 },
    { nombre: "teclado", precio: 1000 },
    { nombre: "audífonos", precio: 1200 }
];


carrito.forEach(function (producto) {
    console.log(`${producto.nombre} - Precio: ${producto.precio}`);
})