const carrito = [];

const producto = {
    nombre: "tablet",
    precio: 14000
}

const producto2 = {
    nombre: "celular",
    precio: 9000
}

carrito.push(producto);
carrito.push(producto2);

const producto3 = {
    nombre: "monitor",
    precio: 8000
}

carrito.unshift(producto3);

console.table(carrito);