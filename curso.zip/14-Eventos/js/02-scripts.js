const navegacion = document.querySelector(".navegacion");

navegacion.addEventListener('click', () => {
    console.log('diste click');
})

navegacion.addEventListener("dbclick", () => {
  console.log("diste doble click");
});

navegacion.addEventListener("mousedown", () => {
  console.log("presionaste el click");
});

navegacion.addEventListener("mouseup", () => {
  console.log("soltaste el click");
});

navegacion.addEventListener("mouseout", () => {
  console.log("sacaste el cursor de la zona del elemento");
});

navegacion.addEventListener("mouseenter", () => {
  console.log("metiste el cursor en la zona del elemento");
});

//para mayor área de detección del evento, aumentar el padding