console.log(1);
//este siembre será una función anónima
document.addEventListener('DOMContentLoaded', () => {
    console.log('html cargado');
})
console.log(3);