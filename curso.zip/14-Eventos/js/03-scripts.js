const busqueda = document.querySelector('.busqueda');

// //cuando presionas una tecla
// busqueda.addEventListener('keydown', () => {
//     console.log('escribiendo');
// })


// //cuando sueltas una tecla
// busqueda.addEventListener("keyup", () => {
//   console.log("escribiendo");
// });

// busqueda.addEventListener("copy", () => {
//   console.log("escribiendo");
// });

// busqueda.addEventListener("paste", () => {
//   console.log("escribiendo");
// });

// busqueda.addEventListener("cut", () => {
//   console.log("escribiendo");
// });

// //todos los anteriores
// busqueda.addEventListener("input", () => {
//   console.log("escribiendo");
// });

// //cuando entras al input y después das click afuera
// busqueda.addEventListener("blur", () => {
//   console.log("escribiendo");
// });

// busqueda.addEventListener("input", (e) => {
//   console.log(e);
// });

// busqueda.addEventListener("input", (e) => {
//   console.log(e.type);
// });

// busqueda.addEventListener("input", (e) => {
//   console.log(e.target);
// });

busqueda.addEventListener("input", (e) => {
    if (e.target.value === '') {
        console.log('falló la validación');
    }
    else {
        console.log(e.target.value);
    }
});