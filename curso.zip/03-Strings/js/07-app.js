const correo = 'KevinDaniel.123@Hotmail.Com';

console.log(correo.toUpperCase());
console.log(correo.toLowerCase());