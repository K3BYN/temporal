const producto = "Monitor de 23 pulgadas";

console.log(producto);
console.log(producto.length);

console.log(producto.indexOf("pulgadas"));

console.log(producto.includes("pulgadas"));
