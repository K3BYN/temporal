const producto = "Monitor de 20 pulgadas";

const texto = " en Promoción".repeat(3);

console.log(texto);
console.log(`${producto} ${texto} !!!`);


const actividad = "Estoy aprendiendo JavaScript Moderno";
console.log(actividad.split(" "));

const hobbies = 'Leer, caminar, escuchar música, escribir, aprender a programar';
console.log(hobbies.split(","));

let array = hobbies.split(",");
console.log(array[0]);
