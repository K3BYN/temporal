const producto = 'Monitor de 24 pulgadas';
console.log(producto);

console.log(producto.replace("pulgadas", '"'));
console.log("----------------------");

console.log(producto.slice(0, 10));
console.log(producto.slice(10));
console.log(producto.slice(10, 0));

console.log('----------------------');

console.log(producto.substring(0, 10));
console.log(producto.substring(10));
console.log(producto.substring(10, 0));

console.log("----------------------");

const nombre = "Kevin";
console.log(nombre.substring(1, 0))
console.log(nombre.charAt(0));