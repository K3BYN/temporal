const vehiculo = {
    nombre: "volstwaven",
    precio: 250000,
    año: 1999,
    motor: 6.0
}

for (let [llave, valor] of Object.entries(vehiculo)) {
    console.log(valor);
    console.log(llave);
}