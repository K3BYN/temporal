//Multiplos de 3 FIZZ
//Múltiplos de 5 BUZZ
//Múlitplos de 3 y de 5 FIZZ BUZZ!!!
//100 números

// for (let i = 1; i < 100; i++){
//     if (i % 15 === 0) {
//         console.log(`${i} FIZZ BUZZ`);
//     }
//     else if (i % 3 === 0) {
//         console.log(`${i} FIZZ`);
//     }
//     else if (i % 5 === 0) {
//         console.log(`${i} BUZZ`);
//     }
//     else console.log(i);
// }

// console.log("---------".repeat(15));


for (let i = 1; i <= 100; i++) {
    (i%15 === 0) ? console.log(`${i} FIZZ BUZZ`) : (i%3 === 0) ? console.log(`${i} FIZZ`) : (i%5 === 0) ? console.log(`${i} BUZZ`) : console.log(`${i}`);
}
