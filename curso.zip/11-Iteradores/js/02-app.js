const carrito = [
  { nombre: "celular", precio: 7800 },
  { nombre: "tablet", precio: 14000, error:true },
  { nombre: "televisión", precio: 12000 },
  { nombre: "colchón", precio: 8000, descuento: true},
  { nombre: "teclado", precio: 1000 },
  { nombre: "audífonos", precio: 1200 },
];

for (let i = 0; i < carrito.length; i++){
    if (carrito[i].descuento)
    {
        console.log(`El artículo ${carrito[i].nombre} tiene descuento!`);
        continue;
    }
    console.log(`${carrito[i].nombre}`)
}

console.log("---".repeat(15));

for (let i = 0; i < carrito.length; i++) {
    if (carrito[i].error) {
        console.log(`El artículo ${carrito[i].nombre} tiene un error, vuelva a intentarlo más tarde`);
        break;
    }
    console.log(`${carrito[i].nombre}`);
}