// Variables
const btnEnviar = document.querySelector('#enviar'),
    email = document.querySelector('#email'),
    asunto = document.querySelector('#asunto'),
    mensaje = document.querySelector('#mensaje');
    formulario = document.querySelector('#enviar-mail')

// EventListeners
eventListeners();
function eventListeners() {
    document.addEventListener('DOMContentLoaded', iniciarApp);
    email.addEventListener('blur', validarFormulario);
    asunto.addEventListener('blur', validarFormulario);
    mensaje.addEventListener("blur", validarFormulario);
}

// Funciones
function iniciarApp() {
    btnEnviar.disabled = true;
    btnEnviar.classList.add('opacity-50', 'cursor-not-allowed');
}

function validarFormulario(e) {
    if (e.target.value.length > 0) {
        // email.style.borderColor = 'cyan';
        e.target.classList.remove('border-red-500');    
    }
    else {
        e.target.classList.add('border-red-500');
        mostrarError();
    }
}

function mostrarError() {
    const mensajeError = document.createElement('p');
    mensajeError.textContent = 'Todos los campos son obligatorios';
    // console.log(mensajeError);
    formulario.appendChild(mensajeError);
}