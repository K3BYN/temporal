const producto = {
  nombre: "monitor 20 pulgadas",
  precio: 300,
  disponible: true,
    mostrarInfo: function () {
        console.log(`El producto: ${this.nombre} tiene un valor de: ${this.precio}`);
  }
};

producto.mostrarInfo();

const producto2 = {
  nombre: "tablet",
  precio: 100,
  disponible: true,
  mostrarInfo: function () {
    console.log(
      `El producto: ${this.nombre} tiene un valor de: ${this.precio}`
    );
  },
};

producto2.mostrarInfo();