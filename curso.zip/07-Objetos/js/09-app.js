"use strict";
const producto = {
  nombre: "monitor 20 pulgadas",
  precio: 300,
  disponible: true,
};
Object.seal(producto);

// Con object.seal y use strict se pueden modificar los valores de las propiedades
//pero no se pueden agregar o eliminar

 producto.disponible = false;
const { nombre, precio, disponible } = producto;

console.log(disponible);

console.log(Object.isSealed(producto));
