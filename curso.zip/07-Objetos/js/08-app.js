"use strict";
const producto = {
  nombre: "monitor 20 pulgadas",
  precio: 300,
  disponible: true,
};
Object.freeze(producto);

// Con object.freeze y use strict el las propiedades del objeto no pueden ser modificadas ni agregar ni eliminar
//porque se comporta tal cual como const
// producto.disponible = false;

// const { nombre, precio, disponible } = producto;

// console.log(disponible);

console.log(Object.isFrozen(producto));