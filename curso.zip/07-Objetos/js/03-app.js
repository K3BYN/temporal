const miObjeto = {
    nombre: "monitor 20 pulgadas",
    precio: 300,
    disponible: true
}

console.log(miObjeto);

miObjeto.imagen = "imagen.jpg";
delete miObjeto.disponible;
console.log(miObjeto);