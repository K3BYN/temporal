const producto = {
    nombre: "monitor 20 pulgadas",
    precio: 300,
    informacion: {
        materiales: {
            fibra: "carbono"
        },
        origen: {
            pais: "mexico",
            estado: "edo. mex"
        }
    }
}

const { nombre, informacion, informacion: { materiales: { fibra} } } = producto;

console.log(nombre);
console.log(informacion);
console.log(fibra);