// Object literals
const producto = {
  nombre: "monitor 20 pulgadas",
  precio: 300,
  disponible: true,
};

// Object constructor
function Producto(nombre, precio) {
    this.nombre = nombre;
    this.precio = precio;
    this.disponible = true;
}

const producto2 = new Producto("tablet", 19000);
console.log(producto2);

const producto3 = new Producto("pc gamer", 40000);
console.log(producto3);