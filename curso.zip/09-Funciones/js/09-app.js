const reproductor = {
    reproducir: function (id) {
        console.log(`Reproduciendo canción con el id ${id}`);
    },
    pausar: function (id) {
        console.log(`Canción con el id ${id} pausada`)
    },
    borrar: function (id) {
        console.log(`Borrando canción con el id ${id}`);
    }
}

reproductor.reproducir(1);
reproductor.pausar(1);
reproductor.borrar(1);
