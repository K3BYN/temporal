let total = 0;

function agregarCarrito(precio) {
    return total += precio;
}
total = agregarCarrito(200);
total = agregarCarrito(300);
total = agregarCarrito(500);
console.log(total);

function calcularImpusto(total) {
    return total * 1.15;
}

let compra = calcularImpusto(total);

console.log(`El total a pagar es de: ${compra}`);