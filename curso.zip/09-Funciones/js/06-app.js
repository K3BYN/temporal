saludar("kevin");

function saludar(nombre, apellido = 'Bienvenido') {
    console.log(`Hola ${nombre} ${apellido}`)
}