const reproductor = {
  reproducir: (id) => console.log(`Reproduciendo canción con el id ${id}`),
  pausar: (id) => console.log(`Canción con el id ${id} pausada`),
  borrar: (id) => console.log(`Borrando canción con el id ${id}`),
  cancion1: "asd",

  set nuevaCancion(cancion) {
    this.cancion = cancion;
    console.log(`añadiendo ${cancion}`);
  },
  get obtenerCancion() {
    console.log(`${this.cancion}`);
  },
};

reproductor.nuevaCancion = "asereje";
reproductor.obtenerCancion;

reproductor.reproducir(1);
reproductor.pausar(1);
reproductor.borrar(1);

console.log(reproductor.cancion);
