let resultado; 

//PI
resultado = Math.PI;

resultado = Math.round(2.6);
resultado = Math.round(2.5);
resultado = Math.round(3.4);

//redondear hacia arriba
resultado = Math.ceil(2.1);
resultado = Math.ceil(2.5);

//redondear hacia abajo
resultado = Math.floor(2.9);
resultado = Math.floor(2.5);

//Absoluto
reusltado = Math.abs(-500);
